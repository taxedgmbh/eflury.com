#!/usr/bin/env python3
"""
mahnlauf.py — Ein KI-gestützter Mahnlauf, Zeile für Zeile.
Tech-Showcase von eFlury Consulting (eflury.com) — Code frei verwendbar (MIT).

Liest offene Posten aus einer CSV und verarbeitet jede Zeile in drei Schritten,
jeder mit dem Modell, das dafür am besten geeignet ist:

  1. BEURTEILEN   Claude (Anthropic)  — liest die chaotische Buchhaltungsnotiz
                                        und entscheidet, was zu tun ist
  2. STRUKTURIEREN GPT-5 mini (OpenAI) — presst die Beurteilung in ein striktes
                                        JSON, das die Buchhaltungssoftware versteht
  3. SCHREIBEN    Gemini (Google)     — formuliert die Mahn-E-Mail in der
                                        Sprache des Kunden (DE/FR/EN)

Kundendaten werden VOR jedem API-Aufruf pseudonymisiert (KUNDE_07 statt
Klarname) und erst im fertigen Entwurf wieder eingesetzt. Es wird nichts
versendet — alle E-Mails landen als Entwürfe im Ordner entwuerfe/.

Voraussetzungen:
    pip install anthropic openai google-genai
    export ANTHROPIC_API_KEY="sk-ant-..."
    export OPENAI_API_KEY="sk-..."
    export GEMINI_API_KEY="..."

Aufruf:
    python mahnlauf.py                  # kompletter Lauf
    python mahnlauf.py --dry-run        # zeigt die Prompts der 1. Zeile, ruft keine API auf
    python mahnlauf.py --limit 5        # nur die ersten 5 Zeilen

Alle Daten in offene_posten.csv sind synthetisch (fiktive Firma Muster
Handwerk AG). Stichtag ist fest auf 2026-07-22 gesetzt, damit der Lauf
reproduzierbar bleibt — im Echtbetrieb: date.today().
"""

import argparse
import csv
import json
import os
import sys
from datetime import date

STICHTAG = date(2026, 7, 22)

MODELL_BEURTEILEN = "claude-opus-4-8"   # Anthropic
MODELL_STRUKTUR = "gpt-5-mini"          # OpenAI
MODELL_TEXT = "gemini-2.5-flash"        # Google

# Listenpreise pro 1 Mio. Tokens (Input, Output), Stand Juli 2026.
# Die Anbieter publizieren in USD; der Kostenzähler rechnet in CHF um.
PREISE = {
    MODELL_BEURTEILEN: (5.00, 25.00),
    MODELL_STRUKTUR: (0.25, 2.00),
    MODELL_TEXT: (0.30, 2.50),
}
KURS_USD_CHF = 0.81  # EZB-Kurs Juli 2026 — bei Bedarf aktualisieren

AKTIONEN = ["erinnerung", "mahnung", "letzte_mahnung", "zurueckstellen", "manuelle_pruefung"]

PROMPT_BEURTEILEN = """Du bist erfahrene:r Debitoren-Sachbearbeiter:in der Muster Handwerk AG,
einem Schweizer KMU. Beurteile diesen offenen Posten (Stichtag {stichtag}):

Rechnung {rechnung_nr} an {kunde_pseudo} über CHF {betrag_chf},
fällig seit {tage_ueberfaellig} Tagen, bisherige Mahnungen: {mahnstufe}.
Notiz aus der Buchhaltung (Originalton, evtl. DE/FR/EN): «{notizen}»

Empfiehl in 3–5 Sätzen das weitere Vorgehen. Regeln des Betriebs:
- Zahlungszusagen, Ratenvereinbarungen, Streitfälle und Teilzahlungen NICHT stur weitermahnen.
- Unklare Fälle (Insolvenzgerüchte, unzustellbare Post, Rechts-/Verrechnungsfragen)
  erfordern eine manuelle Prüfung durch die Geschäftsleitung — nicht mahnen.
- Bei wichtigen Kunden bestimmt, aber beziehungsschonend formulieren.
- Erkenne die Sprache des Kunden (de/fr/en) aus Notiz und Firmenname."""

PROMPT_STRUKTUR = """Wandle die folgende Fall-Beurteilung in ein JSON-Objekt um.
Antworte NUR mit dem JSON, ohne Erklärung, ohne Markdown.

Pflichtfelder:
  "aktion": eine von {aktionen}
  "sprache": "de" | "fr" | "en"   (Sprache des Kunden)
  "ton": "freundlich" | "bestimmt"
  "frist_tage": Ganzzahl 5–20 (neue Zahlungsfrist; 0 wenn keine E-Mail nötig)
  "risiko": "tief" | "mittel" | "hoch"
  "grund": Begründung in max. 140 Zeichen
  "email_senden": true | false    (false bei zurueckstellen/manuelle_pruefung)

Beurteilung des Falls {rechnung_nr}:
{beurteilung}"""

PROMPT_TEXT = """Schreibe eine kurze Zahlungserinnerung als E-Mail (max. 120 Wörter)
in der Sprache "{sprache}", Ton: {ton}, Eskalationsstufe: {aktion}.

Absender: Muster Handwerk AG, Musterstrasse 1, 2540 Grenchen
Empfänger: {kunde_pseudo}
Rechnung {rechnung_nr} über CHF {betrag_chf}, fällig seit {tage_ueberfaellig} Tagen.
Neue Zahlungsfrist: {frist_tage} Tage. Kontext: {grund}

Regeln: Schweizer Geschäftshöflichkeit, keine Drohungen, keine Rechtsbelehrung,
IBAN als Platzhalter [IBAN] lassen. Erste Zeile ist die Betreffzeile
("Betreff:" / "Objet:" / "Subject:" passend zur Sprache). Nur die E-Mail
ausgeben, keine Kommentare."""


# ---------- Die drei Provider-Aufrufe (offizielle SDKs) ----------

def beurteilen(client, prompt: str):
    """Schritt 1 — Claude: liest den Fall und empfiehlt das Vorgehen."""
    msg = client.messages.create(
        model=MODELL_BEURTEILEN,
        max_tokens=600,
        thinking={"type": "adaptive"},
        messages=[{"role": "user", "content": prompt}],
    )
    text = "".join(b.text for b in msg.content if b.type == "text")
    return text, msg.usage.input_tokens, msg.usage.output_tokens


def strukturieren(client, prompt: str):
    """Schritt 2 — GPT-5 mini: erzwingt sauberes JSON."""
    r = client.chat.completions.create(
        model=MODELL_STRUKTUR,
        response_format={"type": "json_object"},
        messages=[{"role": "user", "content": prompt}],
    )
    return r.choices[0].message.content, r.usage.prompt_tokens, r.usage.completion_tokens


def schreiben(client, prompt: str):
    """Schritt 3 — Gemini: formuliert den E-Mail-Entwurf."""
    r = client.models.generate_content(model=MODELL_TEXT, contents=prompt)
    u = r.usage_metadata
    return r.text, u.prompt_token_count, u.candidates_token_count


def json_pruefen(roh: str) -> dict:
    """Validiert die Struktur-Antwort. Wirft ValueError bei Regelverstoss."""
    d = json.loads(roh[roh.index("{"):roh.rindex("}") + 1])
    if d.get("aktion") not in AKTIONEN:
        raise ValueError(f"unbekannte aktion: {d.get('aktion')}")
    if d.get("sprache") not in ("de", "fr", "en"):
        raise ValueError(f"unbekannte sprache: {d.get('sprache')}")
    if not isinstance(d.get("frist_tage"), int) or not 0 <= d["frist_tage"] <= 20:
        raise ValueError(f"frist_tage ungültig: {d.get('frist_tage')}")
    if not isinstance(d.get("email_senden"), bool):
        raise ValueError("email_senden fehlt oder ist kein bool")
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="Prompts zeigen, keine API-Aufrufe")
    ap.add_argument("--limit", type=int, default=0, help="nur die ersten N Zeilen")
    args = ap.parse_args()

    with open("offene_posten.csv", newline="", encoding="utf-8") as f:
        posten = list(csv.DictReader(f))
    if args.limit:
        posten = posten[: args.limit]

    # Pseudonymisierung: Klarnamen verlassen das Haus nicht
    pseudonyme = {}
    for i, p in enumerate(posten, 1):
        pseudonyme[f"KUNDE_{i:02d}"] = p["kunde"]
        p["kunde_pseudo"] = f"KUNDE_{i:02d}"
        p["tage_ueberfaellig"] = (STICHTAG - date.fromisoformat(p["faellig_am"])).days
        p["stichtag"] = STICHTAG.isoformat()
        p["aktionen"] = ", ".join(AKTIONEN)

    if args.dry_run:
        p = posten[0]
        print("— PROMPT 1 (Claude) —\n" + PROMPT_BEURTEILEN.format(**p))
        print("\n— PROMPT 2 (GPT-5 mini) — folgt mit der Beurteilung aus Schritt 1")
        print("— PROMPT 3 (Gemini) — folgt mit dem JSON aus Schritt 2")
        return

    # Clients erst hier — --dry-run läuft ohne installierte SDKs
    import anthropic
    from openai import OpenAI
    from google import genai
    c_claude = anthropic.Anthropic()      # liest ANTHROPIC_API_KEY
    c_openai = OpenAI()                   # liest OPENAI_API_KEY
    c_gemini = genai.Client()             # liest GEMINI_API_KEY

    os.makedirs("entwuerfe", exist_ok=True)
    kosten_chf = 0.0
    ergebnisse = []

    for p in posten:
        # Schritt 1: beurteilen
        beurteilung, t_in, t_out = beurteilen(c_claude, PROMPT_BEURTEILEN.format(**p))
        kosten_chf += (t_in * PREISE[MODELL_BEURTEILEN][0] + t_out * PREISE[MODELL_BEURTEILEN][1]) / 1e6 * KURS_USD_CHF

        # Schritt 2: strukturieren (1 Wiederholung bei ungültigem JSON)
        prompt2 = PROMPT_STRUKTUR.format(beurteilung=beurteilung, **p)
        for versuch in (1, 2):
            roh, t_in, t_out = strukturieren(c_openai, prompt2)
            kosten_chf += (t_in * PREISE[MODELL_STRUKTUR][0] + t_out * PREISE[MODELL_STRUKTUR][1]) / 1e6 * KURS_USD_CHF
            try:
                entscheid = json_pruefen(roh)
                break
            except (ValueError, json.JSONDecodeError) as e:
                if versuch == 2:
                    raise SystemExit(f"{p['rechnung_nr']}: JSON nach 2 Versuchen ungültig — {e}")
                prompt2 += f"\n\nDeine letzte Antwort war ungültig ({e}). Korrigiere sie."

        # Schritt 3: schreiben — nur wenn wirklich eine E-Mail raus soll
        if entscheid["email_senden"] and entscheid["aktion"] not in ("zurueckstellen", "manuelle_pruefung"):
            entwurf, t_in, t_out = schreiben(c_gemini, PROMPT_TEXT.format(**entscheid, **p))
            kosten_chf += (t_in * PREISE[MODELL_TEXT][0] + t_out * PREISE[MODELL_TEXT][1]) / 1e6 * KURS_USD_CHF
            # Pseudonym erst jetzt, lokal, wieder durch den Klarnamen ersetzen
            entwurf = entwurf.replace(p["kunde_pseudo"], p["kunde"])
            with open(f"entwuerfe/{p['rechnung_nr']}.txt", "w", encoding="utf-8") as f:
                f.write(entwurf)

        ergebnisse.append({"rechnung_nr": p["rechnung_nr"], "kunde": p["kunde"],
                           "betrag_chf": p["betrag_chf"], "tage": p["tage_ueberfaellig"],
                           **{k: entscheid[k] for k in ("aktion", "sprache", "ton",
                                                        "frist_tage", "risiko", "grund")}})
        print(f"{p['rechnung_nr']}  {entscheid['aktion']:<16} {entscheid['risiko']:<7} {entscheid['grund']}")

    with open("mahnlauf_ergebnis.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=ergebnisse[0].keys())
        w.writeheader()
        w.writerows(ergebnisse)

    print(f"\n{len(ergebnisse)} Posten verarbeitet · API-Kosten dieses Laufs: ~CHF {kosten_chf:.2f}")
    print("Entscheide: mahnlauf_ergebnis.csv · E-Mail-Entwürfe: entwuerfe/ (NICHTS wurde versendet)")


if __name__ == "__main__":
    sys.exit(main())
