# Mahnlauf-Showcase — drei LLMs, ein Python-Skript

Tech-Showcase von eFlury Consulting (https://eflury.com) · MIT-Lizenz
*(English summary at the bottom.)*

Ein lauffähiges Beispiel dafür, wie ein KMU grosse Sprachmodelle (LLMs) im
Tagesgeschäft einsetzt — nicht als Chat-Fenster, sondern als Schleife:
Ein Skript verarbeitet offene Posten Zeile für Zeile und nutzt für jeden
Schritt das passende Modell.

## Inhalt

| Datei               | Zweck                                                        |
| ------------------- | ------------------------------------------------------------ |
| `mahnlauf.py`       | Das Skript: 3 Schritte, 3 Anbieter, Pseudonymisierung, Kostenzähler |
| `offene_posten.csv` | 40 synthetische offene Posten der fiktiven Muster Handwerk AG |
| `README.md`         | Diese Anleitung                                               |

## Die drei Schritte

1. **Beurteilen** — Claude Opus 4.8 (Anthropic) liest die chaotische
   Buchhaltungsnotiz und entscheidet: erinnern, mahnen, zurückstellen
   oder zur manuellen Prüfung an die Geschäftsleitung geben?
2. **Strukturieren** — GPT-5 mini (OpenAI) presst die Beurteilung in ein
   striktes JSON (maschinell validiert, 1 Wiederholung bei Fehlern).
3. **Schreiben** — Gemini 2.5 Flash (Google) entwirft die Mahn-E-Mail in
   der Sprache des Kunden (DE/FR/EN).

Es wird **nichts versendet** — alle E-Mails landen als Entwürfe im Ordner
`entwuerfe/`, der Entscheid pro Posten in `mahnlauf_ergebnis.csv`.

## Ausprobieren

```bash
# 1. Abhängigkeiten (Python 3.10+)
pip install anthropic openai google-genai

# 2. Eigene API-Schlüssel setzen (nie in den Code schreiben!)
export ANTHROPIC_API_KEY="sk-ant-..."
export OPENAI_API_KEY="sk-..."
export GEMINI_API_KEY="..."

# 3a. Ohne Schlüssel: nur die Prompts ansehen
python mahnlauf.py --dry-run

# 3b. Kleiner Testlauf (5 Zeilen), dann der ganze Datensatz
python mahnlauf.py --limit 5
python mahnlauf.py
```

Richtwert aus unserer Hochrechnung: ein kompletter Lauf über 40 Posten
kostet in der Grössenordnung von 20–30 Rappen an API-Gebühren
(geschätzte Tokenzahlen × Listenpreise Juli 2026, von USD in CHF
umgerechnet — echte Abrechnungen können abweichen).

## Transparenz

- Alle Daten in `offene_posten.csv` sind synthetisch: Firmen, Beträge,
  Notizen und E-Mail-Adressen sind erfunden.
- Die Beispiel-Ausgaben auf eflury.com stammen aus einem Testlauf, bei dem
  exakt diese Prompts über einen einzelnen OpenAI-kompatiblen Endpunkt
  (DeepSeek) liefen, weil in der Entwicklungsumgebung keine Schlüssel der
  drei Anbieter vorlagen. Der Code hier ruft Anthropic, OpenAI und Google
  gemäss deren offiziellen SDKs auf.
- Der Stichtag ist auf 2026-07-22 fixiert, damit der Lauf reproduzierbar
  bleibt — für den Echtbetrieb `STICHTAG` durch `date.today()` ersetzen.

## Sicherheit

- Kundennamen werden vor jedem API-Aufruf pseudonymisiert (`KUNDE_07`)
  und erst im fertigen Entwurf lokal wieder eingesetzt.
- API-Schlüssel kommen ausschliesslich aus Umgebungsvariablen.
- Sonderfälle (Streitfälle, Insolvenzgerüchte, Verrechnungsfragen) mahnt
  das Skript nicht — sie werden als «zurueckstellen» oder
  «manuelle_pruefung» markiert und der Geschäftsleitung vorgelegt.

Fragen, oder soll so etwas auf Ihrer echten Debitorenliste laufen?
→ https://eflury.com/de/kontakt/

---

## English summary

A runnable teaching example of using LLMs in daily SME operations: a Python
script processes 40 synthetic open invoices row by row — Claude (Anthropic)
assesses each case, GPT-5 mini (OpenAI) enforces strict JSON, Gemini
(Google) drafts the reminder email in the customer's language. Nothing is
sent; drafts are written to `entwuerfe/`. Set the three API keys as
environment variables (see above), then run `python mahnlauf.py`.
All data is synthetic; code comments are in German. MIT licence.
Questions → https://eflury.com/en/contact/
